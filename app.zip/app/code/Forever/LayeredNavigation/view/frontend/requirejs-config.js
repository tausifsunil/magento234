var config = {
    paths: {
        fAjaxLayerNav: 'Forever_LayeredNavigation/js/view/layer'
    }
};
