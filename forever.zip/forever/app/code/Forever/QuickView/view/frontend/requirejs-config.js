var config = {
    map: {
        '*': {
            magnificPopup: 'Forever_QuickView/js/jquery.magnific-popup.min',
            foreverQuickViewAbstract: 'Forever_QuickView/js/foreverQuickviewAbstract',
            foreverQuickViewDefault: 'Forever_QuickView/js/foreverQuickviewAbstract'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};
